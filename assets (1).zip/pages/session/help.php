<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$logged = !empty($_SESSION['user_id']);
$name   = $_SESSION['user_name'] ?? null;
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>

  <title>Aide & Support — BillXpert</title>
  <meta name="description"
        content="Support BillXpert — aide, FAQ bêta, signalement de bugs et contacts utiles." />

  <!-- Styles globaux -->
  <link rel="stylesheet" href="/assets/css/global.css">
  <!-- Styles spécifiques à la page d’aide -->
  <link rel="stylesheet" href="/assets/css/help.css">

  <!-- Favicon -->
  <link rel="icon" type="image/png" href="/assets/img/logo-bx.png">

  <!-- JS de la page (gestion formulaire bug, etc.) -->
  <script src="/assets/js/help.js" defer></script>
</head>

<body>
  <!-- HEADER GLOBAL injecté par /assets/js/global.js -->
  <div id="bx-header"></div>
  <!-- espace sous header fixe -->
  <div class="h-5 md:h-10"></div>

  <!-- CONTENU PAGE -->
  <main data-bx-page-anim>

    <!-- SECTION 1 : Présentation & accès au support -->
    <section class="bx-section-main">
      <div class="max-w-4xl mx-auto px-4 py-12 md:py-16">
        

        <h1 class="mt-4 text-3xl md:text-4xl font-semibold tracking-tight bx-split">
          Aide &amp; support de la version bêta
        </h1>

        <?php if (!$logged): ?>
          <p class="mt-4 bx-text-soft text-base md:text-lg max-w-3xl">
            Vous utilisez la version bêta de BillXpert.<br>
            Pour accéder au support complet (signalement de bugs, aide détaillée, réponses rapides),
            <a href="/connexion" class="bx-link">connectez-vous</a> ou
            <a href="/inscription" class="bx-link">créez un compte</a>.
          </p>

          <div class="mt-8 bx-card-soft rounded-2xl p-6">
            <h2 class="text-xl font-semibold mb-3">Fonctionnement rapide</h2>
            <ul class="list-disc pl-5 space-y-2 bx-text-soft">
              <li>Importer une facture (PDF ou photo).</li>
              <li>Lecture automatique avec extraction des champs importants.</li>
              <li>Générateur de facture / Factur-X à partir des données propres.</li>
              <li>Les fonctionnalités avancées sont réservées aux comptes connectés.</li>
            </ul>
          </div>

          <div class="mt-6 bx-card-soft rounded-2xl p-6">
            <h2 class="text-xl font-semibold mb-3">Contacts utiles</h2>
            <p class="bx-text-soft text-sm md:text-base">
              Pour toute question urgente, vous pouvez écrire à :<br>
              <strong>support@billxpert.fr</strong> (adresse à adapter).
            </p>
          </div>

        <?php else: ?>
          <p class="mt-4 bx-text-soft text-base md:text-lg max-w-3xl">
            Bienvenue
            <?= $name ? htmlspecialchars($name, ENT_QUOTES, 'UTF-8') : '' ?>.<br>
            Vous faites partie des testeurs de la bêta BillXpert.
            Vos retours nous aident à améliorer rapidement la plateforme.
          </p>
        <?php endif; ?>
      </div>
    </section>

    <?php if ($logged): ?>
      <!-- SECTION 2 : Formulaire de signalement de bug (réservé aux comptes connectés) -->
      <section class="bx-section-alt">
        <div class="max-w-4xl mx-auto px-4 py-12 md:py-16">
          <h2 class="text-2xl md:text-3xl font-semibold tracking-tight bx-split">
            Signaler un problème ou un bug
          </h2>

          <p class="mt-3 bx-text-soft text-sm md:text-base max-w-3xl">
            Si vous rencontrez un blocage, une erreur d’extraction, un affichage étrange ou tout autre bug,
            merci de nous le signaler via ce formulaire. Votre message sera transmis à l’équipe BillXpert
            avec les informations nécessaires pour reproduire le problème.
          </p>

          <p class="mt-3 bx-text-soft text-xs md:text-sm max-w-3xl">
            Pour éviter le spam, l’envoi de rapports est limité à
            <strong>5 messages par jour et par compte</strong>. Au-delà, le bouton sera désactivé
            jusqu’au lendemain.
          </p>

          <form id="bx-bug-form" class="mt-8 bx-card-soft rounded-2xl p-6">
            <div class="mb-4">
              <label class="block text-sm font-semibold mb-1" for="bug-title">
                Sujet du bug
              </label>
              <input
                type="text"
                id="bug-title"
                name="bug-title"
                required
                class="bx-input w-full mt-1"
                placeholder="Ex. : Erreur lors de l’import d’une facture Leroy Merlin"
              >
            </div>

            <div class="mb-4">
              <label class="block text-sm font-semibold mb-1" for="bug-desc">
                Description détaillée
              </label>
              <textarea
                id="bug-desc"
                name="bug-desc"
                rows="6"
                required
                class="bx-input w-full mt-1"
                placeholder="Expliquez ce qui s’est passé, le type de document, l’action que vous faisiez, et si le bug est reproductible."
              ></textarea>
            </div>

            <button type="submit" id="bx-bug-submit" class="bx-btn-main mt-4">
              Envoyer le rapport
            </button>

          </form>
        </div>
      </section>
    <?php endif; ?>

  </main>

  <!-- FOOTER GLOBAL injecté par /assets/js/global.js -->
  <div id="bx-footer"></div>

  <!-- Animations globales (lettres, reveal…) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
  <script src="/assets/js/global.js"></script>
</body>
</html>