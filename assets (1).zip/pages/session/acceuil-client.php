<?php
declare(strict_types=1);

session_start();

// Si pas connecté → on renvoie vers la page de connexion
if (empty($_SESSION['user_id'])) {
    header('Location: /connexion');
    exit;
}
?>
<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Espace bêta — BillXpert</title>
  <meta name="description"
        content="Espace bêta privé BillXpert : suivi d’avancement du projet, modules en cours de construction et journal de bord de la bêta.">

  <!-- Styles globaux du site (header/footer, boutons, etc.) -->
  <link rel="stylesheet" href="/assets/css/global.css"/>
  <!-- Styles spécifiques à l’espace client/bêta -->
  <link rel="stylesheet" href="/assets/css/acceuil-client.css"/>

  <!-- Tailwind (utilisé par le header/footer globaux) -->
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="icon" type="image/png" href="/assets/img/logo-bx.png">
</head>
<body>

  <!-- HEADER GLOBAL injecté par /assets/js/global.js -->
  <div id="bx-header"></div>
  <!-- espace sous header fixe -->
  <div class="h-16 md:h-20"></div>

  <!-- CONTENU DE LA PAGE ESPACE BÊTA -->
  <div class="bx-client-shell" data-bx-page-anim>
    <main class="bx-client-main">
      <!-- SECTION REMERCIEMENT BÊTA -->
      <section class="bx-beta-intro">
        <div class="bx-beta-pill">Bêta BillXpert</div>
        <h1 class="bx-beta-title">
          Merci de tester BillXpert en avant-première 🙌
        </h1>
        <p class="bx-beta-text">
          Votre participation à la bêta nous aide à construire un outil vraiment utile pour les artisans,
          TPE et PME. Chaque test, chaque retour, chaque bug signalé contribue directement à améliorer
          l’expérience de tous les futurs utilisateurs.
        </p>
        <p class="bx-beta-text bx-beta-text-dim">
          Nous vous souhaitons une excellente expérience sur BillXpert. N’hésitez pas à remonter vos idées,
          vos frustrations et vos besoins&nbsp;: c’est le moment où nous pouvons encore tout ajuster.
        </p>
      </section>

      <!-- SECTION ÉTAT D'AVANCEMENT DU PROJET -->
      <section class="bx-status-section">
        <header class="bx-section-header">
          <div>
            <h2 class="bx-section-title">État d’avancement du projet</h2>
            <p class="bx-section-sub">
              Aperçu rapide de la progression des principaux modules de BillXpert.
            </p>
          </div>
          <div class="bx-status-badges">
            <span class="bx-status-badge bx-status-badge-primary">
              Phase bêta active
            </span>
            <span class="bx-status-badge">
              V1 publique prévue : 2026
            </span>
          </div>
        </header>

        <div class="bx-status-grid">
          <!-- Carte globale -->
          <article class="bx-status-card bx-status-card-main">
            <h3 class="bx-status-card-title">Vue d’ensemble</h3>
            <p class="bx-status-card-text">
              Le cœur du projet est déjà en place : réception des documents, extraction des données,
              conversion vers Factur-X et génération de devis/factures. La bêta permet de stabiliser
              ces blocs avant l’ouverture publique.
            </p>

            <div class="bx-status-progress-list">
              <!-- Extracteur : 50% - En construction -->
              <div class="bx-status-progress-item">
                <div class="bx-status-progress-top">
                  <span>Extracteur de factures</span>
                  <span class="bx-status-progress-label">En construction</span>
                </div>
                <div class="bx-status-progress-bar">
                  <div class="bx-status-progress-fill" data-progress="50"></div>
                </div>
              </div>

              <!-- Générateur : 75% - Bientôt dispo en bêta publique -->
              <div class="bx-status-progress-item">
                <div class="bx-status-progress-top">
                  <span>Générateur de devis &amp; factures</span>
                  <span class="bx-status-progress-label">Bientôt dispo en bêta publique</span>
                </div>
                <div class="bx-status-progress-bar">
                  <div class="bx-status-progress-fill" data-progress="75"></div>
                </div>
              </div>

              <!-- Espace client & comptabilisation : 30% - En construction -->
              <div class="bx-status-progress-item">
                <div class="bx-status-progress-top">
                  <span>Espace client &amp; comptabilisation</span>
                  <span class="bx-status-progress-label">En construction</span>
                </div>
                <div class="bx-status-progress-bar">
                  <div class="bx-status-progress-fill" data-progress="30"></div>
                </div>
              </div>

              <!-- Préparation Factur-X & réforme 2026 : 100% - En attente de certification -->
              <div class="bx-status-progress-item">
                <div class="bx-status-progress-top">
                  <span>Préparation Factur-X &amp; réforme 2026</span>
                  <span class="bx-status-progress-label">En attente de certification</span>
                </div>
                <div class="bx-status-progress-bar">
                  <div class="bx-status-progress-fill" data-progress="100"></div>
                </div>
              </div>
            </div>
          </article>

          <!-- Mini cartes -->
          <article class="bx-status-card">
            <h3 class="bx-status-card-title">Ce que vous pouvez déjà tester</h3>
            <ul class="bx-status-list">
              <li>
                <strong>Générateur en bêta dès le 1er janvier (objectif).</strong>
              </li>
            </ul>
          </article>

          <article class="bx-status-card">
            <h3 class="bx-status-card-title">Ce qui arrive bientôt</h3>
            <ul class="bx-status-list">
              <li>Générateur de devis complet pour le BTP.</li>
              <li>Tableau de bord client (volumes, clients, statistiques).</li>
              <li>Entraînement de l’IA BillXpert.</li>
              <li>Amélioration de la précision sur des cas limites (photos floues, manuscrits, etc.).</li>
            </ul>
          </article>
        </div>
      </section>

      <!-- SECTION BLOG BÊTA -->
      <section class="bx-blog-section">
        <header class="bx-section-header">
          <div>
            <h2 class="bx-section-title">Blog bêta BillXpert</h2>
            <p class="bx-section-sub">
              Journal de bord du projet, mises à jour techniques et coulisses du développement.
            </p>
          </div>
        </header>

        <div id="bx-blog-list" class="bx-blog-list">
          <!-- Les articles seront injectés en JS -->
        </div>

        <p class="bx-blog-note">
          À terme, cette section sera alimentée directement depuis votre espace créateur BillXpert.
        </p>
      </section>
    </main>
  </div>

  <!-- FOOTER GLOBAL injecté par /assets/js/global.js -->
  <div id="bx-footer"></div>

  <!-- GSAP (si utilisé par global.js pour les animations bxPageFadeIn, bx-split, etc.) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>

  <!-- JS global (header/footer + effets) -->
  <script src="/assets/js/global.js"></script>

  <!-- JS spécifique à cette page (barres de progression + blog bêta) -->
  <script src="/assets/js/acceuil-client.js"></script>
</body>
</html>