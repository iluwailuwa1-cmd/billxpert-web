// Mettre à jour la date "Dernière mise à jour"
(function () {
  var el = document.getElementById("update-date");
  if (!el) return;
  el.textContent = new Date().toLocaleDateString("fr-FR");
})();