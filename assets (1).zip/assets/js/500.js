<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>Erreur 500 — Un souci côté serveur | BillXpert</title>
  <meta name="robots" content="noindex, nofollow"/>

  <!-- (optionnel) styles globaux de ton site -->
  <link rel="stylesheet" href="/assets/css/global.css">

  <style>
    :root {
      --bx-navy:#0d1b2a;
      --bx-blue:#2563eb;
      --bx-border:rgba(255,255,255,.12);
    }
    body {
      margin:0;
      background:
        radial-gradient(1000px 520px at 20% -10%, rgba(37,99,235,.18), transparent 60%),
        var(--bx-navy);
      color:#e9eef6;
      font-family:system-ui,-apple-system,Segoe UI,Roboto,Inter,Arial,sans-serif;
    }
    .wrap {
      max-width:72rem;
      margin:0 auto;
      padding:3.5rem 1rem;
    }
    .head {
      display:flex;
      justify-content:space-between;
      align-items:center;
      gap:.75rem;
      color:#cfe1ff;
    }
    .card {
      background:rgba(255,255,255,.06);
      border:1px solid var(--bx-border);
      border-radius:18px;
      padding:1.25rem;
    }
    .btn {
      display:inline-flex;
      align-items:center;
      gap:.5rem;
      padding:.9rem 1.15rem;
      border-radius:14px;
      border:1px solid var(--bx-border);
      background:#2251d1;
      color:#fff;
      text-decoration:none;
      font-size:.95rem;
    }
    .btn:hover {
      background:#1e46b9;
    }
    .btn-ghost {
      background:transparent;
      color:#e9eef6;
    }
    .btn-ghost:hover {
      background:rgba(255,255,255,.08);
    }
    input[type="search"] {
      width:100%;
      background:rgba(255,255,255,.06);
      border:1px solid var(--bx-border);
      color:#fff;
      padding:.9rem 1rem;
      border-radius:12px;
      font-size:.95rem;
    }
    .links {
      display:grid;
      gap:.8rem;
    }
    @media (min-width:860px) {
      .grid {
        display:grid;
        grid-template-columns:1.1fr .9fr;
        gap:1rem;
      }
    }
    .muted {
      color:#c8d2df;
    }
    h1 {
      margin:.2rem 0 0 0;
      font-size:clamp(2rem,6vw,3rem);
      line-height:1.1;
    }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="head">
      <div style="display:flex;align-items:center;gap:.6rem">
        <img src="/assets/img/logo-bx-light.png" alt="BillXpert" width="28" height="28"/>
        <strong>BillXpert</strong>
      </div>
      <a href="/" class="btn-ghost" aria-label="Retour à l’accueil">← Retour à l’accueil</a>
    </div>

    <div class="grid" style="margin-top:2rem;align-items:start">
      <!-- Colonne A -->
      <div class="card">
        <div class="muted" style="letter-spacing:.08em;">ERREUR 500</div>
        <h1>Oups 😬 Une erreur serveur s’est produite</h1>
        <p class="muted" style="max-width:60ch">
          Ce n’est pas vous, c’est nous. Le serveur a rencontré un problème.
          Nos équipes ont été notifiées. Vous pouvez réessayer ou utiliser les raccourcis ci-dessous.
        </p>

        <div style="display:flex;gap:.6rem;flex-wrap:wrap;margin-top:.6rem">
          <a href="/" class="btn">← Accueil</a>
          <a id="support-link" href="#" class="btn btn-ghost">Contacter le support</a>
          <a href="#" onclick="location.reload();return false;" class="btn btn-ghost">Réessayer</a>
        </div>

        <div class="card" style="margin-top:1rem">
          <div class="muted" style="font-size:.9rem">Détails</div>
          <div style="font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.95rem">
            Incident ID : <strong id="incident-id">—</strong><br>
            Page demandée : <strong id="incident-url">—</strong>
          </div>
        </div>
      </div>

      <!-- Colonne B -->
      <div class="card">
        <div class="links">
          <a class="btn-ghost" href="/fr/facture-x.html">📘 Comprendre la Facture-X</a>
          <a class="btn-ghost" href="/fr/#gratuit">🧾 Version gratuite — Réception Facture-X</a>
          <a class="btn-ghost" href="/fr/#preinscription">🚀 Pré-inscription Premium</a>
          <a class="btn-ghost" href="/fr/tarif-et-avantages.html">💶 Tarifs &amp; avantages</a>
        </div>

        <form role="search" class="card" style="margin-top:1rem" action="/fr/">
          <label class="muted" for="s">Rechercher sur le site</label>
          <div style="display:grid;grid-template-columns:1fr auto;gap:.6rem;margin-top:.5rem">
            <input id="s" type="search" name="s" placeholder="Ex. Facture-X, PDP, 2026…">
            <button class="btn" type="submit">Rechercher</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="/assets/js/error-500.js"></script>
</body>
</html>