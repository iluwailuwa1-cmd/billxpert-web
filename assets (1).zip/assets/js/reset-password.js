// assets/js/reset-password.js
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("bx-reset-form");
  const passwordInput = document.getElementById("password");
  const passwordConfirmInput = document.getElementById("password_confirm");

  const tokenInput = document.getElementById("token"); // token envoyé en POST
  const emailInput = document.getElementById("email"); // email caché

  const globalError = document.getElementById("bx-reset-error-global");
  const submitBtn = document.querySelector(".bx-reset-submit");

  if (!form || !passwordInput || !passwordConfirmInput || !tokenInput || !emailInput) {
    return;
  }

  // Récupération du token + email dans l’URL
  const params = new URLSearchParams(window.location.search);
  const urlToken = params.get("token") || "";
  const urlEmail = params.get("email") || "";

  if (!urlToken || !urlEmail) {
    if (globalError) {
      globalError.textContent =
        "Ce lien n’est pas valide. Merci de refaire une demande de réinitialisation depuis la page « mot de passe oublié ».";
      globalError.style.display = "block";
    }
    if (submitBtn) {
      submitBtn.disabled = true;
    }
    return;
  }

  // On injecte token + email dans le formulaire
  tokenInput.value = urlToken;
  emailInput.value = urlEmail;

  function showFieldError(id, show, message) {
    const err = document.querySelector('[data-error-for="' + id + '"]');
    if (!err) return;
    if (message) {
      err.textContent = message;
    }
    err.style.display = show ? "block" : "none";
  }

  function showGlobalError(message) {
    if (!globalError) return;
    globalError.textContent = message;
    globalError.style.display = "block";
  }

  function hideGlobalError() {
    if (!globalError) return;
    globalError.style.display = "none";
  }

  function validatePasswords() {
    let ok = true;

    const pwd = (passwordInput.value || "").trim();
    const pwd2 = (passwordConfirmInput.value || "").trim();

    showFieldError("password", false);
    showFieldError("password_confirm", false);

    const complexityRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;

    if (!complexityRegex.test(pwd)) {
      ok = false;
      showFieldError(
        "password",
        true,
        "Le mot de passe doit contenir au moins 8 caractères, avec une majuscule, une minuscule, un chiffre et un caractère spécial."
      );
    }

    if (!pwd2 || pwd !== pwd2) {
      ok = false;
      showFieldError(
        "password_confirm",
        true,
        "Les deux mots de passe doivent être identiques."
      );
    }

    return ok;
  }

  async function handleSubmit(e) {
    e.preventDefault();

    hideGlobalError();

    if (!validatePasswords()) {
      return;
    }

    if (!tokenInput.value || !emailInput.value) {
      showGlobalError(
        "Le lien de réinitialisation est invalide. Merci de refaire une demande."
      );
      return;
    }

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = "Mise à jour…";
    }

    try {
      const formData = new FormData(form);

      const response = await fetch(form.action || "/api/auth/forgot-password.php", {
        method: "POST",
        body: formData,
        credentials: "same-origin",
        headers: {
          "X-Requested-With": "XMLHttpRequest"
        }
      });

      let data = null;
      const ct = response.headers.get("Content-Type") || "";
      if (ct.includes("application/json")) {
        data = await response.json().catch(() => null);
      }

      if (response.ok && data && data.ok) {
        const redirectUrl = (data && data.redirect) || "/acceuil-client";
        window.location.href = redirectUrl;
        return;
      }

      let msg =
        "La réinitialisation n’a pas pu être effectuée. Merci de vérifier les informations et de réessayer.";

      if (data && typeof data === "object" && data.code) {
        if (data.code === "token_not_found_or_expired" || data.code === "invalid_token") {
          msg =
            "Ce lien de réinitialisation n’est plus valide. Merci de refaire une demande depuis la page « mot de passe oublié ».";
        } else if (data.code === "invalid_password") {
          msg =
            data.error ||
            "Le mot de passe ne respecte pas les règles de sécurité indiquées.";
        } else if (data.code === "too_many_requests" || data.code === "too_many_attempts") {
          msg =
            "Nombre de tentatives dépassé. Merci de refaire une demande depuis la page « mot de passe oublié ».";
        } else if (data.message) {
          msg = data.message;
        }
      } else if (response.status === 400) {
        msg =
          "Certaines informations sont manquantes ou invalides. Merci de les corriger puis de réessayer.";
      } else if (response.status >= 500) {
        msg = "Erreur serveur. Merci de réessayer dans quelques instants.";
      }

      showGlobalError(msg);
    } catch (err) {
      showGlobalError(
        "Erreur réseau ou serveur. Merci de vérifier votre connexion et de réessayer."
      );
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = "Mettre à jour mon mot de passe";
      }
    }
  }

  form.addEventListener("submit", handleSubmit);
});