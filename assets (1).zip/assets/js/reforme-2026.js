document.addEventListener("DOMContentLoaded", async () => {
  // Inject header
  const header = document.getElementById("bx-header");
  if (header) {
    const h = await fetch("/partials/header.html").then(r => r.text());
    header.innerHTML = h;
  }

  // Inject footer
  const footer = document.getElementById("bx-footer");
  if (footer) {
    const f = await fetch("/partials/footer.html").then(r => r.text());
    footer.innerHTML = f;
  }
});