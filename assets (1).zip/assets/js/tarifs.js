// /assets/js/tarifs.js
document.addEventListener("DOMContentLoaded", () => {
  // Année dans le footer global (#y)
  const y = document.getElementById("y");
  if (y) y.textContent = new Date().getFullYear();

  // Effet "split" sur les titres .bx-split
  (function () {
    const nodes = document.querySelectorAll(".bx-split");
    nodes.forEach(node => {
      if (node.dataset.split) return;
      node.dataset.split = "1";

      const raw = (node.textContent || "").replace(/Facture-?X/g, "Facture-X");
      const tokens = raw.split(/(\s+)/);
      let html = "";
      let delay = 0;

      tokens.forEach(tok => {
        if (/^\s+$/.test(tok)) {
          html += tok;
          return;
        }
        const chars = tok.split("");
        html += "<span class='bx-word'>";
        chars.forEach((c, i) => {
          html += `<span class="bx-char" style="transition-delay:${delay + i * 16}ms">${c}</span>`;
        });
        html += "</span>";
        delay += Math.max(40, chars.length * 10);
      });

      node.setAttribute("aria-label", raw.trim());
      node.innerHTML = html;
    });
  })();

  // Effet de reveal au scroll sur .bx-reveal et .bx-split
  (function () {
    const els = Array.prototype.slice.call(
      document.querySelectorAll(".bx-reveal, .bx-split")
    );
    if (!("IntersectionObserver" in window)) {
      els.forEach(e => e.classList.add("in"));
      return;
    }

    const io = new IntersectionObserver(
      entries => {
        const vh = window.innerHeight || document.documentElement.clientHeight;
        entries.forEach(ent => {
          const el = ent.target;
          const r = ent.boundingClientRect;
          const anyVisible = r.top < vh && r.bottom > 0;

          if (ent.isIntersecting || anyVisible) {
            el.classList.add("in");
            el.classList.remove("out");
          } else {
            el.classList.remove("in");
            el.classList.add("out");
          }
        });
      },
      { threshold: [0, 0.08, 0.25, 0.6, 1] }
    );

    els.forEach(e => io.observe(e));
  })();
});