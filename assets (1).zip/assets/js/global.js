// ======================================================
// 0. Gestion du thème global (clair / sombre)
// ======================================================

const BX_THEME_KEY = "bx-theme";

function bxGetInitialTheme() {
  let saved = null;
  try {
    saved = localStorage.getItem(BX_THEME_KEY);
  } catch (e) {
    // ignore
  }

  if (saved === "light" || saved === "dark") {
    return saved;
  }

  // Si rien en stockage, on peut se baser sur la classe actuelle
  const root = document.documentElement;
  if (root.classList.contains("theme-light")) return "light";
  if (root.classList.contains("theme-dark")) return "dark";

  // Par défaut : sombre
  return "dark";
}

function bxApplyThemeVisual(theme) {
  // Logos clair/sombre (header + footer)
  const logos = document.querySelectorAll(
    ".bx-header-logo img, .bx-footer-logo-row img"
  );
  logos.forEach((logo) => {
    if (theme === "light") {
      logo.src = "/assets/img/logo-bx.png"; // logo sombre pour fond clair
    } else {
      logo.src = "/assets/img/logo-bx-light.png"; // logo clair pour fond sombre
    }
  });
}

function bxSetTheme(theme) {
  const root = document.documentElement;
  root.classList.remove("theme-light", "theme-dark");
  root.classList.add("theme-" + theme);

  try {
    localStorage.setItem(BX_THEME_KEY, theme);
  } catch (e) {
    // ignore
  }

  bxApplyThemeVisual(theme);
}

function bxInitThemeToggle() {
  // IMPORTANT : on gère maintenant TOUS les boutons de thème, pas seulement le premier
  const buttons = document.querySelectorAll("[data-bx-theme-toggle]");
  if (!buttons.length) return;

  function sync(theme) {
    const isLight = theme === "light";

    buttons.forEach((btn) => {
      btn.setAttribute("aria-pressed", isLight ? "true" : "false");
      const icon = btn.querySelector("[data-bx-theme-icon]");
      if (icon) {
        icon.textContent = isLight ? "☀️" : "🌙";
      }
    });

    bxApplyThemeVisual(theme);
  }

  // Sync initial avec le thème actuel
  const current = bxGetInitialTheme();
  sync(current);

  // Clic sur n'importe quel switch => toggle global
  buttons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const root = document.documentElement;
      const curr = root.classList.contains("theme-light") ? "light" : "dark";
      const next = curr === "light" ? "dark" : "light";
      bxSetTheme(next);
      sync(next);
    });
  });
}

// Appliquer le thème dès le chargement du script (limite le flash)
(function () {
  const initialTheme = bxGetInitialTheme();
  bxSetTheme(initialTheme);
})();

// ======================================================
// 0 bis. Menu mobile (burger)
// ======================================================

function bxInitMobileNav() {
  const toggle = document.querySelector("[data-bx-nav-toggle]");
  const panel = document.querySelector("[data-bx-nav-panel]");
  if (!toggle || !panel) return;

  toggle.addEventListener("click", () => {
    const isOpen = panel.classList.toggle("is-open");
    toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
  });

  // Fermer le menu quand on clique sur un lien
  panel.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      panel.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
    });
  });
}

// ======================================================
// 1. Animation de fade-in de la page
// ======================================================
function bxPageFadeIn() {
  const containers = document.querySelectorAll("[data-bx-page-anim]");
  if (!containers.length) return;

  requestAnimationFrame(() => {
    containers.forEach((el) => {
      el.classList.add("bx-page-visible");
    });
  });
}

// ======================================================
// 2. Injection du header/footer
// ======================================================
function bxInjectFragment(containerId, url, callback) {
  const container = document.getElementById(containerId);
  if (!container) return;

  fetch(url)
    .then((res) => res.text())
    .then((html) => {
      container.innerHTML = html;
      if (typeof callback === "function") callback();
    })
    .catch((err) => console.error("[BX Layout]", url, err));
}

// ======================================================
// 3. INIT GLOBAL (header + footer + fade-in page)
// ======================================================
document.addEventListener("DOMContentLoaded", () => {
  // Inject HEADER puis initialiser le bouton de thème + burger
  bxInjectFragment("bx-header", "/partials/header.php", () => {
    bxInitThemeToggle();
    bxInitMobileNav();

    const currentTheme = bxGetInitialTheme();
    bxApplyThemeVisual(currentTheme);
  });

  // Inject FOOTER
  bxInjectFragment("bx-footer", "/partials/footer.html", () => {
    const y = document.getElementById("year");
    if (y) y.textContent = new Date().getFullYear();

    const currentTheme = bxGetInitialTheme();
    bxApplyThemeVisual(currentTheme);
  });

  // Animation globale de page
  bxPageFadeIn();
});

// ======================================================
// 4. Effets globaux BX : année, split lettres, reveal
// ======================================================
(function () {
  function bxInitYear() {
    ["year", "y"].forEach((id) => {
      const el = document.getElementById(id);
      if (el) {
        el.textContent = new Date().getFullYear();
      }
    });
  }

  // Effet "split" sur les titres .bx-split (animation lettre par lettre)
  function bxInitSplit() {
    const nodes = document.querySelectorAll(".bx-split");
    nodes.forEach((node) => {
      if (node.dataset.split) return;
      node.dataset.split = "1";

      const raw = (node.textContent || "").replace(/Facture-?X/g, "Facture-X");
      const tokens = raw.split(/(\s+)/);
      let html = "";
      let delay = 0;

      tokens.forEach((tok) => {
        if (/^\s+$/.test(tok)) {
          html += tok;
          return;
        }
        const chars = tok.split("");
        html += "<span class='bx-word'>";
        chars.forEach((c, i) => {
          html += `<span class="bx-char" style="transition-delay:${delay + i * 16}ms">${c}</span>`;
        });
        html += "</span>";
        delay += Math.max(40, chars.length * 10);
      });

      node.setAttribute("aria-label", raw.trim());
      node.innerHTML = html;
    });
  }

  // Effet de reveal au scroll pour .bx-reveal et .bx-split
  function bxInitReveal() {
    const els = Array.prototype.slice.call(
      document.querySelectorAll(".bx-reveal, .bx-split")
    );
    if (!els.length) return;

    if (!("IntersectionObserver" in window)) {
      els.forEach((e) => e.classList.add("in"));
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        const vh = window.innerHeight || document.documentElement.clientHeight;
        entries.forEach((ent) => {
          const el = ent.target;
          const r = ent.boundingClientRect;
          const anyVisible = r.top < vh && r.bottom > 0;

          if (ent.isIntersecting || anyVisible) {
            el.classList.add("in");
            el.classList.remove("out");
          } else {
            el.classList.remove("in");
            el.classList.add("out");
          }
        });
      },
      { threshold: [0, 0.08, 0.25, 0.6, 1] }
    );

    els.forEach((e) => io.observe(e));
  }
    
  document.addEventListener("DOMContentLoaded", () => {
    bxInitYear();
    bxInitSplit();
    bxInitReveal();
  });
})();
