// JS spécifique Conditions d’utilisation
document.addEventListener("DOMContentLoaded", function () {
  const el = document.getElementById("update-date");
  if (el) {
    el.textContent = new Date().toLocaleDateString("fr-FR");
  }

  // L’année du footer (#year / #y) est gérée par global.js
});