(function () {
  const stepRequest = document.getElementById("bx-reset-step-request");
  const stepNewPass = document.getElementById("bx-reset-step-newpass");

  const requestForm = document.getElementById("bx-reset-request-form");
  const newPassForm = document.getElementById("bx-reset-newpass-form");

  const requestError = document.getElementById("bx-reset-request-error");
  const requestSuccess = document.getElementById("bx-reset-request-success");
  const newPassError = document.getElementById("bx-reset-newpass-error");
  const newPassSuccess = document.getElementById("bx-reset-newpass-success");

  const resetTokenInput = document.getElementById("reset_token");

  function showFieldError(fieldName, show, message) {
    const selector =
      fieldName === "reset_email" ||
      fieldName === "reset_password" ||
      fieldName === "reset_password_confirm"
        ? '[data-error-for="' + fieldName + '"]'
        : '[data-error-for="' + fieldName + '"]';

    const el = document.querySelector(selector);
    if (!el) return;
    if (message) el.textContent = message;
    el.style.display = show ? "block" : "none";
  }

  function clearFieldErrors(scopeForm) {
    if (!scopeForm) return;
    const errs = scopeForm.querySelectorAll(".bx-error");
    errs.forEach((el) => {
      el.style.display = "none";
    });
  }

  function setGlobalMessage(targetError, targetSuccess, type, message) {
    if (targetError) {
      targetError.style.display = type === "error" ? "block" : "none";
      if (type === "error") targetError.textContent = message || "";
    }
    if (targetSuccess) {
      targetSuccess.style.display = type === "success" ? "block" : "none";
      if (type === "success") targetSuccess.textContent = message || "";
    }
  }

  // --- Détecter la présence d'un token dans l'URL ---
  const params = new URLSearchParams(window.location.search);
  const token = params.get("token") || params.get("t") || "";
  if (token && stepNewPass && stepRequest && resetTokenInput) {
    stepRequest.style.display = "none";
    stepNewPass.style.display = "block";
    resetTokenInput.value = token;
  } else {
    if (stepRequest) stepRequest.style.display = "block";
    if (stepNewPass) stepNewPass.style.display = "none";
  }

  // --- Étape 1 : demande de réinitialisation ---
  if (requestForm) {
    requestForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      clearFieldErrors(requestForm);
      setGlobalMessage(requestError, requestSuccess, "none", "");

      const prenom = (document.getElementById("prenom")?.value || "").trim();
      const nom = (document.getElementById("nom")?.value || "").trim();
      const email = (document.getElementById("email")?.value || "").trim();
      const tel = (document.getElementById("telephone")?.value || "").trim();
      const siret = (document.getElementById("siret")?.value || "").replace(/\D+/g, "");

      let ok = true;

      if (!prenom) {
        ok = false;
        showFieldError("prenom", true, "Ce champ est obligatoire.");
      }
      if (!nom) {
        ok = false;
        showFieldError("nom", true, "Ce champ est obligatoire.");
      }
      if (!email || !email.includes("@")) {
        ok = false;
        showFieldError("email", true, "Merci de saisir une adresse e-mail valide.");
      }
      if (!tel) {
        ok = false;
        showFieldError("telephone", true, "Ce champ est obligatoire.");
      }
      if (!siret || siret.length !== 14) {
        ok = false;
        showFieldError("siret", true, "Le SIRET doit contenir 14 chiffres.");
      }

      if (!ok) {
        setGlobalMessage(
          requestError,
          requestSuccess,
          "error",
          "Merci de corriger les champs indiqués."
        );
        return;
      }

      const submitBtn = requestForm.querySelector(".bx-reset-submit");
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = "Envoi en cours…";
      }

      try {
        const formData = new FormData(requestForm);
        const response = await fetch(requestForm.action || "/api/auth/forgot-password.php", {
          method: "POST",
          body: formData,
          credentials: "same-origin"
        });

        let data = null;
        try {
          data = await response.json();
        } catch (_) {
          data = null;
        }

        if (response.ok && data && data.ok) {
          setGlobalMessage(
            requestError,
            requestSuccess,
            "success",
            data.message ||
              "Si les informations correspondent à un compte existant, un e-mail de réinitialisation vient d’être envoyé."
          );
        } else {
          const msg =
            (data && (data.error || data.message)) ||
            "Impossible d’envoyer l’e-mail de réinitialisation pour le moment.";
          setGlobalMessage(requestError, requestSuccess, "error", msg);
        }
      } catch (err) {
        setGlobalMessage(
          requestError,
          requestSuccess,
          "error",
          "Erreur réseau ou serveur. Merci de réessayer dans quelques instants."
        );
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = "Envoyer le lien de réinitialisation";
        }
      }
    });
  }

  // --- Étape 2 : nouveau mot de passe ---
  if (newPassForm) {
    newPassForm.addEventListener("submit", async function (e) {
      e.preventDefault();

      clearFieldErrors(newPassForm);
      setGlobalMessage(newPassError, newPassSuccess, "none", "");

      const email = (document.getElementById("reset_email")?.value || "").trim();
      const pwd = (document.getElementById("reset_password")?.value || "").trim();
      const pwd2 = (document.getElementById("reset_password_confirm")?.value || "").trim();
      const tokenValue = resetTokenInput ? resetTokenInput.value.trim() : "";

      let ok = true;

      if (!tokenValue) {
        ok = false;
        setGlobalMessage(
          newPassError,
          newPassSuccess,
          "error",
          "Lien de réinitialisation invalide ou expiré."
        );
        return;
      }

      if (!email || !email.includes("@")) {
        ok = false;
        showFieldError("reset_email", true, "Merci de saisir une adresse e-mail valide.");
      }

      const complexityRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;
      if (!complexityRegex.test(pwd)) {
        ok = false;
        showFieldError(
          "reset_password",
          true,
          "Le mot de passe doit contenir au moins 8 caractères dont une majuscule, une minuscule, un chiffre et un caractère spécial."
        );
      }

      if (pwd !== pwd2) {
        ok = false;
        showFieldError(
          "reset_password_confirm",
          true,
          "Les deux mots de passe doivent être identiques."
        );
      }

      if (!ok) {
        setGlobalMessage(
          newPassError,
          newPassSuccess,
          "error",
          "Merci de corriger les champs indiqués."
        );
        return;
      }

      const submitBtn = newPassForm.querySelector(".bx-reset-submit");
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = "Enregistrement…";
      }

      try {
        const formData = new FormData(newPassForm);
        const response = await fetch(newPassForm.action || "/api/auth/reset-password.php", {
          method: "POST",
          body: formData,
          credentials: "same-origin"
        });

        let data = null;
        try {
          data = await response.json();
        } catch (_) {
          data = null;
        }

        if (response.ok && data && data.ok) {
          setGlobalMessage(
            newPassError,
            newPassSuccess,
            "success",
            data.message ||
              "Votre mot de passe a été mis à jour. Vous pouvez maintenant vous connecter avec vos nouveaux identifiants."
          );

          setTimeout(() => {
            window.location.href = "/connexion";
          }, 2500);
        } else {
          const msg =
            (data && (data.error || data.message)) ||
            "Impossible de mettre à jour le mot de passe pour le moment.";
          setGlobalMessage(newPassError, newPassSuccess, "error", msg);
        }
      } catch (err) {
        setGlobalMessage(
          newPassError,
          newPassSuccess,
          "error",
          "Erreur réseau ou serveur. Merci de réessayer dans quelques instants."
        );
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = "Enregistrer le nouveau mot de passe";
        }
      }
    });
  }
})();