document.addEventListener("DOMContentLoaded", () => {
  const form      = document.getElementById("bx-bug-form");
  const successEl = document.getElementById("bx-bug-success");
  const errorEl   = document.getElementById("bx-bug-error");
  const submitBtn = document.getElementById("bx-bug-submit");

  if (!form) return;

  let limitReached = false;

  function setButtonDisabled(disabled, label) {
    if (!submitBtn) return;
    submitBtn.disabled = disabled;
    if (disabled) {
      submitBtn.style.opacity = "0.6";
      submitBtn.style.cursor = "not-allowed";
    } else {
      submitBtn.style.opacity = "";
      submitBtn.style.cursor = "";
    }
    if (label) {
      submitBtn.textContent = label;
    }
  }

  function resetMessages() {
    if (successEl) {
      successEl.classList.add("hidden");
      successEl.textContent = "✔ Bug envoyé, merci pour votre aide !";
    }
    if (errorEl) {
      errorEl.classList.add("hidden");
      errorEl.textContent = "⚠ Une erreur est survenue lors de l’envoi. Merci de réessayer dans quelques instants.";
    }
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    resetMessages();

    // Si on sait déjà que la limite est atteinte : on bloque avant même l'appel réseau
    if (limitReached) {
      if (errorEl) {
        errorEl.textContent = "⚠ Limite atteinte : vous avez déjà envoyé 5 rapports aujourd’hui. Vous pourrez réessayer demain.";
        errorEl.classList.remove("hidden");
      }
      setButtonDisabled(true, "Limite atteinte (5/5 aujourd’hui)");
      return;
    }

    const titleInput = document.getElementById("bug-title");
    const descInput  = document.getElementById("bug-desc");

    const title = titleInput ? titleInput.value.trim() : "";
    const desc  = descInput  ? descInput.value.trim()  : "";

    if (!title || !desc) {
      if (errorEl) {
        errorEl.textContent = "⚠ Merci de remplir le sujet et la description.";
        errorEl.classList.remove("hidden");
      }
      return;
    }

    // état "en cours"
    setButtonDisabled(true, "Envoi en cours...");

    let responseData = null;

    try {
      const res = await fetch("/api/help/report.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, desc })
      });

      try {
        responseData = await res.json();
      } catch (_) {
        // JSON invalide ou vide, on laissera un message générique
      }

      // Si limite atteinte côté serveur (HTTP 429 ou message dédié)
      const isLimitError =
        res.status === 429 ||
        (responseData && typeof responseData.error === "string" &&
         responseData.error.toLowerCase().includes("limite atteinte"));

      if (isLimitError) {
        limitReached = true;

        if (errorEl) {
          const msg = responseData && responseData.error
            ? responseData.error
            : "Limite atteinte : vous avez déjà envoyé 5 rapports aujourd’hui.";
          errorEl.textContent = "⚠ " + msg;
          errorEl.classList.remove("hidden");
        }

        setButtonDisabled(true, "Limite atteinte (5/5 aujourd’hui)");
        return;
      }

      if (res.ok && responseData && responseData.ok) {
        // Succès
        if (successEl) {
          let msg = "✔ Bug envoyé, merci pour votre aide !";

          if (responseData.limit && typeof responseData.limit.used_today === "number") {
            const used = responseData.limit.used_today;
            const max  = responseData.limit.max_per_day ?? 5;
            msg += ` (Rapports aujourd’hui : ${used}/${max})`;

            // Si on vient d’atteindre la limite avec cette requête
            if (used >= max) {
              limitReached = true;
              setButtonDisabled(true, `Limite atteinte (${used}/${max} aujourd’hui)`);
            } else {
              setButtonDisabled(false, "Envoyer le rapport");
            }
          } else {
            setButtonDisabled(false, "Envoyer le rapport");
          }

          successEl.textContent = msg;
          successEl.classList.remove("hidden");
        }

        form.reset();
      } else {
        // Erreur renvoyée par l’API (autre que limite)
        const apiError = responseData && responseData.error
          ? String(responseData.error)
          : "Erreur inconnue côté serveur.";

        if (errorEl) {
          errorEl.textContent = "⚠ " + apiError;
          errorEl.classList.remove("hidden");
        }

        // On réactive le bouton sauf si le serveur a explicitement bloqué (cas au-dessus)
        if (!limitReached) {
          setButtonDisabled(false, "Envoyer le rapport");
        }
      }
    } catch (err) {
      // Erreur réseau / fetch
      if (errorEl) {
        errorEl.textContent = "⚠ Impossible de contacter le serveur. Vérifiez votre connexion et réessayez.";
        errorEl.classList.remove("hidden");
      }
      if (!limitReached) {
        setButtonDisabled(false, "Envoyer le rapport");
      }
    }
  });
});