// assets/js/inscription.js
(function () {
  const step1 = document.getElementById("bx-step-1");
  const step2 = document.getElementById("bx-step-2");
  const step3 = document.getElementById("bx-step-3");
  const stepLabel = document.getElementById("bx-step-label");
  const stepTitle = document.getElementById("bx-step-title");
  const stepSub = document.getElementById("bx-step-sub");
  const progressBar = document.getElementById("bx-progress-bar");
  const smallNote = document.getElementById("bx-small-note");

  const btnBack = document.getElementById("btn-back");
  const btnNext = document.getElementById("btn-next");
  const form = document.getElementById("bx-signup-form");
  const betaAccept = document.getElementById("beta-accept");
  const betaAcceptError = document.getElementById("beta-accept-error");
  const codeInput = document.getElementById("code-verif");
  const codeError = document.getElementById("code-error");

  // Bouton renvoi code + timer
  const resendBtn = document.getElementById("bx-resend-code");
  const resendTimer = document.getElementById("bx-resend-timer");

  // Modale
  const modalOverlay = document.getElementById("bx-modal-overlay");
  const modalIcon = document.getElementById("bx-modal-icon");
  const modalTitle = document.getElementById("bx-modal-title");
  const modalMessage = document.getElementById("bx-modal-message");
  const modalBtnMain = document.getElementById("bx-modal-btn-main");
  const modalBtnSecondary = document.getElementById("bx-modal-btn-secondary");
  const modalBtnTertiary = document.getElementById("bx-modal-btn-tertiary");
  const modalClose = document.getElementById("bx-modal-close");

  let currentStep = 1;
  let registrationDone = false;
  let resendIntervalId = null;
  let resendRemaining = 0;

  function getFieldErrorEl(fieldName) {
    return document.querySelector('[data-error-for="' + fieldName + '"]');
  }

  function showStep(step) {
    currentStep = step;

    if (step1) step1.classList.remove("active");
    if (step2) step2.classList.remove("active");
    if (step3) step3.classList.remove("active");

    if (step === 1) {
      if (step1) step1.classList.add("active");
      if (stepLabel) stepLabel.textContent = "Étape 1 / 3";
      if (stepTitle) stepTitle.textContent = "Vos informations d’entreprise";
      if (stepSub) {
        stepSub.textContent =
          "Remplissez les champs ci-dessous pour que l’on comprenne qui vous êtes et dans quel contexte vous utiliserez BillXpert.";
      }
      if (progressBar) progressBar.style.width = "33%";
      if (btnBack) btnBack.disabled = true;
      if (btnNext) btnNext.textContent = "Continuer";
      if (smallNote) {
        smallNote.textContent =
          "Étape suivante : lecture et acceptation du contrat de bêta.";
      }
    } else if (step === 2) {
      if (step2) step2.classList.add("active");
      if (stepLabel) stepLabel.textContent = "Étape 2 / 3";
      if (stepTitle) stepTitle.textContent = "Contrat de participation à la bêta";
      if (stepSub) {
        stepSub.textContent =
          "Merci de lire le contrat ci-dessous puis de confirmer votre accord pour passer à la vérification par code.";
      }
      if (progressBar) progressBar.style.width = "66%";
      if (btnBack) btnBack.disabled = false;
      if (btnNext) btnNext.textContent = "Accepter et recevoir le code";
      if (smallNote) {
        smallNote.textContent =
          "Après acceptation, un code vous sera envoyé par e-mail.";
      }
    } else {
      if (step3) step3.classList.add("active");
      if (stepLabel) stepLabel.textContent = "Étape 3 / 3";
      if (stepTitle) stepTitle.textContent = "Vérification de votre inscription";
      if (stepSub) {
        stepSub.textContent =
          "Saisissez le code reçu pour terminer l’inscription à la bêta BillXpert.";
      }
      if (progressBar) progressBar.style.width = "100%";
      if (btnBack) btnBack.disabled = false;
      if (btnNext) btnNext.textContent = "Finaliser l’inscription";
      if (smallNote) {
        smallNote.textContent =
          "En cas de problème de code, vous pouvez demander un nouvel envoi ou contacter le support BillXpert.";
      }
    }
  }

  // Validation locale ETAPE 1
  function validateStep1() {
    let ok = true;

    const requiredIds = [
      "prenom",
      "nom",
      "email",
      "telephone",
      "entreprise",
      "siret",
      "password",
      "password_confirm"
    ];

    // Cache les erreurs
    requiredIds.forEach((id) => {
      const err = getFieldErrorEl(id);
      if (err) err.style.display = "none";
    });

    // Champs obligatoires non vides
    requiredIds.forEach((id) => {
      const input = document.getElementById(id);
      const err = getFieldErrorEl(id);
      if (!input || !err) return;

      if (!input.value.trim()) {
        ok = false;
        err.textContent = "Ce champ est obligatoire.";
        err.style.display = "block";
      }
    });

    // SIRET : 14 chiffres
    const siretInput = document.getElementById("siret");
    const siretErr = getFieldErrorEl("siret");
    if (siretInput && siretErr) {
      const siretValue = siretInput.value.replace(/\D+/g, "");
      if (siretValue.length !== 14) {
        ok = false;
        siretErr.textContent = "Le SIRET doit contenir 14 chiffres.";
        siretErr.style.display = "block";
      }
    }

    // email simple
    const emailInput = document.getElementById("email");
    const emailErr = getFieldErrorEl("email");
    if (emailInput && emailErr) {
      const value = emailInput.value.trim();
      if (value && !value.includes("@")) {
        ok = false;
        emailErr.textContent = "Merci de saisir une adresse e-mail valide.";
        emailErr.style.display = "block";
      }
    }

    // mot de passe : complexité
    const passwordInput = document.getElementById("password");
    const passwordConfirmInput = document.getElementById("password_confirm");
    const passwordErr = getFieldErrorEl("password");
    const passwordConfirmErr = getFieldErrorEl("password_confirm");

    if (passwordInput && passwordErr) {
      const pwd = passwordInput.value.trim();
      const complexityRegex =
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,}$/;

      if (!complexityRegex.test(pwd)) {
        ok = false;
        passwordErr.textContent =
          "Le mot de passe doit contenir au moins 8 caractères dont une majuscule, une minuscule, un chiffre et un caractère spécial.";
        passwordErr.style.display = "block";
      }
    }

    // confirmation
    if (
      passwordInput &&
      passwordConfirmInput &&
      passwordConfirmErr &&
      passwordInput.value &&
      passwordConfirmInput.value &&
      passwordInput.value !== passwordConfirmInput.value
    ) {
      ok = false;
      passwordConfirmErr.textContent =
        "Les deux mots de passe ne correspondent pas.";
      passwordConfirmErr.style.display = "block";
    }

    return ok;
  }

  // --- Modale ---

  function closeModal() {
    if (!modalOverlay) return;
    modalOverlay.classList.remove("active");
    modalOverlay.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
  }

  function configureButton(btn, label, action) {
    if (!btn) return;
    if (!label) {
      btn.style.display = "none";
      btn.onclick = null;
      return;
    }
    btn.style.display = "inline-flex";
    btn.textContent = label;
    btn.onclick = action;
  }

  function openModal(config) {
    if (!modalOverlay || !modalTitle || !modalMessage || !modalIcon) return;

    const { type, title, message, buttons } = config;

    modalTitle.textContent = title;
    modalMessage.textContent = message || "";
    modalIcon.className = "bx-modal-icon"; // reset
    if (type === "success") {
      modalIcon.classList.add("bx-modal-icon--success");
    } else if (type === "warning") {
      modalIcon.classList.add("bx-modal-icon--warning");
    } else {
      modalIcon.classList.add("bx-modal-icon--error");
    }

    configureButton(
      modalBtnMain,
      buttons && buttons.main && buttons.main.label,
      buttons && buttons.main && buttons.main.onClick
    );
    configureButton(
      modalBtnSecondary,
      buttons && buttons.secondary && buttons.secondary.label,
      buttons && buttons.secondary && buttons.secondary.onClick
    );
    configureButton(
      modalBtnTertiary,
      buttons && buttons.tertiary && buttons.tertiary.label,
      buttons && buttons.tertiary && buttons.tertiary.onClick
    );

    modalOverlay.classList.add("active");
    modalOverlay.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  if (modalClose) {
    modalClose.addEventListener("click", closeModal);
  }
  if (modalOverlay) {
    modalOverlay.addEventListener("click", function (e) {
      if (e.target === modalOverlay) {
        closeModal();
      }
    });
  }

  function applyServerFieldErrors(fieldErrors) {
    if (!fieldErrors || typeof fieldErrors !== "object") return;

    let firstField = null;

    Object.keys(fieldErrors).forEach((fieldName) => {
      const msg = fieldErrors[fieldName];
      const errEl = getFieldErrorEl(fieldName);
      const input = document.getElementById(fieldName);

      if (errEl) {
        errEl.textContent = msg || "Ce champ est invalide.";
        errEl.style.display = "block";
      }
      if (!firstField && input) {
        firstField = input;
      }
    });

    if (firstField && typeof firstField.focus === "function") {
      firstField.focus();
    }
  }

  // --- Cooldown renvoi de code ---

  function stopResendCooldown() {
    if (resendIntervalId) {
      clearInterval(resendIntervalId);
      resendIntervalId = null;
    }
    if (resendBtn) {
      resendBtn.disabled = false;
    }
    if (resendTimer) {
      resendTimer.style.display = "none";
      resendTimer.textContent = "";
    }
  }

  function startResendCooldown(seconds) {
    if (!resendBtn || !resendTimer) return;

    resendRemaining = seconds;
    resendBtn.disabled = true;
    resendTimer.style.display = "inline";
    resendTimer.textContent = "(" + resendRemaining + " s)";

    if (resendIntervalId) {
      clearInterval(resendIntervalId);
    }

    resendIntervalId = setInterval(function () {
      resendRemaining -= 1;
      if (resendRemaining <= 0) {
        stopResendCooldown();
        return;
      }
      resendTimer.textContent = "(" + resendRemaining + " s)";
    }, 1000);
  }

  // --- Etape 1 : appel /api/auth/register.php ---

  async function doRegisterIfNeeded() {
    if (registrationDone) {
      return true;
    }
    if (!form) return false;

    if (btnNext) {
      btnNext.disabled = true;
      btnNext.textContent = "Enregistrement…";
    }

    try {
      const formData = new FormData(form);
      const response = await fetch(form.action || "/api/auth/register.php", {
        method: "POST",
        body: formData,
        credentials: "same-origin"
      });

      let data = null;
      try {
        data = await response.json();
      } catch (_) {
        data = {};
      }

      if (response.ok && data && data.ok) {
        registrationDone = true;
        return true;
      }

      if (response.status === 409) {
        openModal({
          type: "warning",
          title: "Adresse e-mail déjà utilisée",
          message:
            (data && data.error) ||
            "Un compte existe déjà avec cette adresse e-mail. Vous pouvez vous connecter ou réinitialiser votre mot de passe.",
          buttons: {
            main: {
              label: "Se connecter",
              onClick: function () {
                window.location.href = "/connexion";
              }
            },
            secondary: {
              label: "Réinitialiser le mot de passe",
              onClick: function () {
                window.location.href = "/reset-mot-de-passe";
              }
            },
            tertiary: {
              label: "Retour à l’accueil",
              onClick: function () {
                window.location.href = "/acceuil";
              }
            }
          }
        });
        return false;
      }

      if (response.status === 400 && data && data.fieldErrors) {
        applyServerFieldErrors(data.fieldErrors);
      }

      openModal({
        type: "error",
        title: "Inscription impossible",
        message:
          (data && data.error) ||
          "Certains champs semblent invalides. Corrigez-les puis relancez l’inscription.",
        buttons: {
          main: {
            label: "Réessayer",
            onClick: function () {
              closeModal();
            }
          },
          secondary: {
            label: "Retour à l’accueil",
            onClick: function () {
              window.location.href = "/acceuil";
            }
          },
          tertiary: null
        }
      });
      return false;
    } catch (err) {
      openModal({
        type: "error",
        title: "Erreur de connexion",
        message:
          "Erreur réseau ou serveur. Vérifiez votre connexion Internet et réessayez dans quelques instants.",
        buttons: {
          main: {
            label: "Réessayer",
            onClick: function () {
              closeModal();
            }
          },
          secondary: {
            label: "Retour à l’accueil",
            onClick: function () {
              window.location.href = "/acceuil";
            }
          },
          tertiary: null
        }
      });
      return false;
    } finally {
      if (btnNext && currentStep === 1) {
        btnNext.disabled = false;
        btnNext.textContent = "Continuer";
      }
    }
  }

  // --- Etape 2 / renvoi : appel /api/auth/send-code.php ---

  async function sendVerificationCode() {
    const emailInput = document.getElementById("email");
    const email = emailInput ? emailInput.value.trim() : "";

    if (!email) {
      const emailErr = getFieldErrorEl("email");
      if (emailErr) {
        emailErr.textContent = "Merci de saisir une adresse e-mail.";
        emailErr.style.display = "block";
      }
      return false;
    }

    if (btnNext && currentStep === 2) {
      btnNext.disabled = true;
      btnNext.textContent = "Envoi du code…";
    }
    if (resendBtn && currentStep === 3) {
      resendBtn.disabled = true;
    }

    try {
      const fd = new FormData();
      fd.append("email", email);

      const response = await fetch("/api/auth/send-code.php", {
        method: "POST",
        body: fd,
        credentials: "same-origin"
      });

      let data = null;
      try {
        data = await response.json();
      } catch (_) {
        data = {};
      }

      if (response.ok && data && data.ok) {
        // démarrer le cooldown 60s
        startResendCooldown(60);
        return true;
      }

      if (response.status === 429) {
        openModal({
          type: "warning",
          title: "Trop de demandes",
          message:
            (data && data.error) ||
            "Vous avez déjà demandé un code récemment. Merci de patienter une minute avant une nouvelle demande.",
          buttons: {
            main: {
              label: "Fermer",
              onClick: function () {
                closeModal();
              }
            },
            secondary: null,
            tertiary: null
          }
        });
        return false;
      }

      if (response.status === 404) {
        openModal({
          type: "error",
          title: "Compte introuvable",
          message:
            (data && data.error) ||
            "Aucun compte correspondant n’a été trouvé. Merci de recommencer l’inscription.",
          buttons: {
            main: {
              label: "Recommencer l’inscription",
              onClick: function () {
                window.location.href = "/inscription";
              }
            },
            secondary: {
              label: "Retour à l’accueil",
              onClick: function () {
                window.location.href = "/acceuil";
              }
            },
            tertiary: null
          }
        });
        return false;
      }

      openModal({
        type: "error",
        title: "Erreur lors de l’envoi du code",
        message:
          (data && data.error) ||
          "Impossible d’envoyer le code pour le moment. Merci de réessayer plus tard.",
        buttons: {
          main: {
            label: "Réessayer plus tard",
            onClick: function () {
              closeModal();
            }
          },
          secondary: null,
          tertiary: null
        }
      });
      return false;
    } catch (err) {
      openModal({
        type: "error",
        title: "Erreur de connexion",
        message:
          "Erreur réseau ou serveur. Vérifiez votre connexion Internet et réessayez dans quelques instants.",
        buttons: {
          main: {
            label: "Réessayer",
            onClick: function () {
              closeModal();
            }
          },
          secondary: null,
          tertiary: null
        }
      });
      return false;
    } finally {
      if (btnNext && currentStep === 2) {
        btnNext.disabled = false;
        btnNext.textContent = "Accepter et recevoir le code";
      }
      if (resendBtn && currentStep === 3 && resendRemaining <= 0) {
        resendBtn.disabled = false;
      }
    }
  }

  // --- Etape 3 : appel /api/auth/verify-code.php ---

  async function verifyCodeAndFinish() {
    if (!form) return;

    const codeValue = (codeInput && codeInput.value) ? codeInput.value.trim() : "";
    if (!codeValue) {
      if (codeError) codeError.style.display = "block";
      return;
    }
    if (codeError) codeError.style.display = "none";

    if (btnNext) {
      btnNext.disabled = true;
      btnNext.textContent = "Vérification…";
    }

    try {
      const formData = new FormData(form);
      const response = await fetch("/api/auth/verify-code.php", {
        method: "POST",
        body: formData,
        credentials: "same-origin"
      });

      let data = null;
      try {
        data = await response.json();
      } catch (_) {
        data = {};
      }

      const redirectUrl = (data && data.redirect) || "/acceuil-client";

      if (response.ok && data && data.ok) {
        openModal({
          type: "success",
          title: "Inscription réussie",
          message:
            data.message ||
            "Votre compte BillXpert est maintenant vérifié. Vous pouvez accéder à votre espace.",
          buttons: {
            main: {
              label: "Accéder à l’espace client",
              onClick: function () {
                window.location.href = redirectUrl;
              }
            },
            secondary: {
              label: "Retour à l’accueil",
              onClick: function () {
                window.location.href = "/acceuil";
              }
            },
            tertiary: null
          }
        });

        if (btnBack) btnBack.disabled = true;
        if (btnNext) {
          btnNext.disabled = true;
          btnNext.textContent = "Inscription terminée";
        }
        return;
      }

      if (data && data.code === "invalid_code") {
        if (codeError) {
          codeError.textContent = data.error || "Le code saisi est incorrect.";
          codeError.style.display = "block";
        }
        return;
      }

      if (data && data.code === "code_not_found_or_expired") {
        if (codeError) {
          codeError.textContent =
            data.error ||
            "Le code est invalide ou expiré. Demandez un nouveau code et réessayez.";
          codeError.style.display = "block";
        }
        return;
      }

      openModal({
        type: "error",
        title: "Erreur lors de la vérification",
        message:
          (data && data.error) ||
          "Une erreur est survenue lors de la vérification du code.",
        buttons: {
          main: {
            label: "Réessayer",
            onClick: function () {
              closeModal();
            }
          },
          secondary: {
            label: "Retour à l’accueil",
            onClick: function () {
              window.location.href = "/acceuil";
            }
          },
          tertiary: null
        }
      });
    } catch (err) {
      openModal({
        type: "error",
        title: "Erreur de connexion",
        message:
          "Erreur réseau ou serveur. Vérifiez votre connexion Internet et réessayez dans quelques instants.",
        buttons: {
          main: {
            label: "Réessayer",
            onClick: function () {
              closeModal();
            }
          },
          secondary: {
            label: "Retour à l’accueil",
            onClick: function () {
              window.location.href = "/acceuil";
            }
          },
          tertiary: null
        }
      });
    } finally {
      if (btnNext && currentStep === 3) {
        btnNext.disabled = false;
        btnNext.textContent = "Finaliser l’inscription";
      }
    }
  }

  // --- Navigation étapes ---

  if (btnNext) {
    btnNext.addEventListener("click", async function () {
      if (currentStep === 1) {
        if (!validateStep1()) return;
        const ok = await doRegisterIfNeeded();
        if (ok) showStep(2);
        return;
      }

      if (currentStep === 2) {
        if (!betaAccept.checked) {
          if (betaAcceptError) betaAcceptError.style.display = "block";
          return;
        } else if (betaAcceptError) {
          betaAcceptError.style.display = "none";
        }
        const ok = await sendVerificationCode();
        if (ok) {
          showStep(3);
        }
        return;
      }

      if (currentStep === 3) {
        verifyCodeAndFinish();
      }
    });
  }

  if (btnBack) {
    btnBack.addEventListener("click", function () {
      if (currentStep === 2) {
        showStep(1);
      } else if (currentStep === 3) {
        showStep(2);
      }
    });
  }

  // Empêcher la soumission native du formulaire
  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (currentStep === 3) {
        verifyCodeAndFinish();
      }
    });
  }

  // Bouton "Renvoyer le code"
  if (resendBtn) {
    resendBtn.addEventListener("click", function () {
      if (currentStep !== 3) return;
      sendVerificationCode();
    });
  }
})();