// JS spécifique à la page Mentions légales
document.addEventListener("DOMContentLoaded", () => {
  // Mettre à jour la date du jour
  const updateDate = document.getElementById("update-date");
  if (updateDate) {
    updateDate.textContent = new Date().toLocaleDateString("fr-FR");
  }

  // L'année du footer est déjà gérée par global.js (#year / #y)
});