(function () {
  const STORAGE_KEY = 'bx_cookie_consent_v1'; // change la version si tu modifies la bannière

  function getConsent() {
    try {
      return localStorage.getItem(STORAGE_KEY);
      // si tu veux "même session" seulement :
      // return sessionStorage.getItem(STORAGE_KEY);
    } catch (e) {
      return null;
    }
  }

  function setConsent(value) {
    try {
      localStorage.setItem(STORAGE_KEY, value);
      // ou sessionStorage.setItem(...) pour une session
    } catch (e) {
      // on ignore si le stockage est bloqué
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    const banner = document.getElementById('bx-cookie-banner');
    if (!banner) return;

    // Si déjà décidé → on ne montre pas
    if (getConsent()) {
      banner.style.display = 'none';
      return;
    }

    // Sinon, on affiche
    banner.style.display = 'block';

    const btnAccept = document.getElementById('bx-cookie-accept');
    const btnReject = document.getElementById('bx-cookie-reject');

    if (btnAccept) {
      btnAccept.addEventListener('click', function () {
        setConsent('accepted');
        banner.style.display = 'none';
        // ici plus tard tu pourras activer Google Analytics, etc.
      });
    }

    if (btnReject) {
      btnReject.addEventListener('click', function () {
        setConsent('rejected');
        banner.style.display = 'none';
        // ici tu t'assures de ne PAS charger les scripts non essentiels
      });
    }
  });
})();