(function () {
  // mêmes clés que le bandeau global (ex: 6 mois)
  var KEY = "bx_cookie_prefs_v1";
  var COOKIE = "bx_consent";
  var SIX_MONTHS = 60 * 60 * 24 * 180; // en secondes

  var tgl = document.getElementById("bx-toggle-analytics");
  var status = document.getElementById("bx-status");

  if (!tgl || !status) {
    return;
  }

  function now() {
    return Date.now();
  }

  function exp() {
    return now() + SIX_MONTHS * 1000;
  }

  function readPrefs() {
    try {
      var raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function writePrefs(prefs) {
    try {
      localStorage.setItem(KEY, JSON.stringify(prefs));
    } catch (e) {
      // ignore
    }
    try {
      document.cookie =
        COOKIE +
        "=" +
        encodeURIComponent(prefs.status) +
        "; Max-Age=" +
        SIX_MONTHS +
        "; Path=/; SameSite=Lax; Secure";
    } catch (e) {
      // ignore
    }
  }

  function isExpired(p) {
    return !p || !p.exp || p.exp < now();
  }

  function setToggle(on) {
    tgl.dataset.on = on ? "1" : "0";
    tgl.setAttribute("aria-checked", on ? "true" : "false");
  }

  function uiStatus(msg, cls) {
    status.textContent = msg;
    status.className = "status " + (cls || "");
  }

  // Init à l'ouverture de la page
  (function init() {
    var p = readPrefs();
    var on = !!(p && p.analytics && !isExpired(p));

    setToggle(on);

    if (p && !isExpired(p)) {
      uiStatus(
        on
          ? "Analytics actuellement : ACTIVÉ"
          : "Analytics actuellement : DÉSACTIVÉ",
        on ? "ok" : "warn"
      );
    } else {
      uiStatus(
        "Aucun choix enregistré — veuillez sauvegarder vos préférences.",
        "warn"
      );
    }
  })();

  // Toggle au clic
  tgl.addEventListener("click", function () {
    var current = tgl.dataset.on === "1";
    setToggle(!current);
  });

  // Toggle au clavier (Espace / Entrée)
  tgl.addEventListener("keydown", function (e) {
    if (e.key === " " || e.key === "Enter") {
      e.preventDefault();
      var current = tgl.dataset.on === "1";
      setToggle(!current);
    }
  });

  // Enregistrer mes choix
  var acceptBtn = document.getElementById("bx-accept");
  if (acceptBtn) {
    acceptBtn.addEventListener("click", function () {
      var allow = tgl.dataset.on === "1";
      var prefs = {
        status: "custom",
        analytics: allow,
        ts: now(),
        exp: exp(),
      };

      writePrefs(prefs);

      uiStatus(
        "Vos préférences ont été enregistrées. (" +
          (allow ? "Analytics ACTIVÉ" : "Analytics DÉSACTIVÉ") +
          ")",
        "ok"
      );

      if (allow) {
        window.dispatchEvent(new Event("bx:consent:analytics:accepted"));
      }
      window.dispatchEvent(new Event("bx:consent:accepted"));
    });
  }

  // Tout refuser
  var declineBtn = document.getElementById("bx-decline");
  if (declineBtn) {
    declineBtn.addEventListener("click", function () {
      var prefs = {
        status: "declined",
        analytics: false,
        ts: now(),
        exp: exp(),
      };

      writePrefs(prefs);
      setToggle(false);

      uiStatus(
        "Vous avez refusé les cookies non essentiels. (Analytics DÉSACTIVÉ)",
        "ok"
      );

      window.dispatchEvent(new Event("bx:consent:declined"));
    });
  }
})();