// /assets/js/home-landing.js

document.addEventListener("DOMContentLoaded", function () {
  var el = document.getElementById("bx-countdown");
  if (!el) return;

  // Cible : +13 jours �  10h
  var target = new Date(2026, 2, 4, 10, 0, 0, 0); // 10/12/2025 �  10h (mois = 11 => décembre)
  target.setDate(target.getDate() + 43); // +43 jours

  function pad(n) {
    return (n < 10 ? "0" : "") + n;
  }

  function tick() {
    var dms = target.getTime() - Date.now();
    if (dms <= 0) {
      el.textContent = "Prochaine étape : 🧪 Tests (imminente)";
      return;
    }

    var days = Math.floor(dms / 86400000);
    var hrs  = Math.floor((dms % 86400000) / 3600000);
    var mins = Math.floor((dms % 3600000) / 60000);

    el.textContent =
      "Étape suivante (objectif) dans : " +
      days + " j " +
      pad(hrs) + " h " +
      pad(mins) + " min";
  }

  tick();
  setInterval(tick, 60000);
});
