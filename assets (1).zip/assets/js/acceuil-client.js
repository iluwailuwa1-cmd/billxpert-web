(function () {
  // Animation des barres de progression
  function animateProgressBars() {
    const fills = document.querySelectorAll(".bx-status-progress-fill");
    fills.forEach((fill) => {
      const value = parseInt(fill.getAttribute("data-progress") || "0", 10);
      setTimeout(() => {
        fill.style.width = Math.max(0, Math.min(100, value)) + "%";
      }, 50);
    });
  }

  // Démo : Blog interne
  const demoPosts = [
    {
      title: "Première vague de test de l’extracteur",
      tag: "Journal de bord",
      date: "Décembre 2025",
      excerpt:
        "Nous avons lancé les premiers tests réels sur des factures BTP, avec un focus sur la reconnaissance des montants et de la TVA.",
    },
    {
      title: "Connexion & inscription : sécurisation terminée",
      tag: "Mise à jour",
      date: "Décembre 2025",
      excerpt:
        "Le module d’inscription et de connexion a été stabilisé. Les comptes bêta peuvent désormais être créés et gérés plus facilement.",
    },
    {
      title: "Prochain objectif : générateur de devis",
      tag: "Roadmap",
      date: "Décembre 2025",
      excerpt:
        "Nous préparons un générateur de devis pensé d’abord pour le BTP, avec lignes d’articles, taux de TVA et totaux contrôlés.",
    },
  ];

  function renderBlog() {
    const container = document.getElementById("bx-blog-list");
    if (!container) return;

    container.innerHTML = "";
    demoPosts.forEach((post) => {
      const card = document.createElement("article");
      card.className = "bx-blog-card";

      card.innerHTML = `
        <div class="bx-blog-meta">
          <span class="bx-blog-tag">${post.tag}</span>
          <span class="bx-blog-date">${post.date}</span>
        </div>
        <h3 class="bx-blog-title">${post.title}</h3>
        <p class="bx-blog-excerpt">${post.excerpt}</p>
        <div class="bx-blog-actions">
          <a href="#" class="bx-blog-link">Lire plus (bientôt)</a>
          <span>→</span>
        </div>
      `;

      container.appendChild(card);
    });
  }

  // Init
  document.addEventListener("DOMContentLoaded", () => {
    animateProgressBars();
    renderBlog();
  });
})();