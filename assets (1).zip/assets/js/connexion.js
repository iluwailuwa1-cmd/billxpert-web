// assets/js/connexion.js
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("bx-login-form");
  const identifiantInput = document.getElementById("identifiant");
  const passwordInput = document.getElementById("password");

  const globalError = document.getElementById("bx-login-error-global");
  const submitBtn = document.querySelector(".bx-login-submit");
  const inactiveCta = document.getElementById("bx-login-inactive-cta");

  if (!form || !identifiantInput || !passwordInput) {
    return;
  }

  function showFieldError(id, show) {
    const err = document.querySelector('[data-error-for="' + id + '"]');
    if (!err) return;
    err.style.display = show ? "block" : "none";
  }

  function showGlobalError(message) {
    if (!globalError) return;
    globalError.textContent = message;
    globalError.style.display = "block";
  }

  function hideGlobalError() {
    if (!globalError) return;
    globalError.style.display = "none";
  }

  function hideInactiveCta() {
    if (inactiveCta) inactiveCta.style.display = "none";
  }

  async function handleSubmit(e) {
    e.preventDefault();

    let ok = true;
    const identifiant = (identifiantInput.value || "").trim();
    const password = (passwordInput.value || "").trim();

    if (!identifiant) {
      ok = false;
      showFieldError("identifiant", true);
    } else {
      showFieldError("identifiant", false);
    }

    if (!password) {
      ok = false;
      showFieldError("password", true);
    } else {
      showFieldError("password", false);
    }

    if (!ok) {
      hideGlobalError();
      hideInactiveCta();
      return;
    }

    hideGlobalError();
    hideInactiveCta();

    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = "Connexion…";
    }

    try {
      const formData = new FormData(form);

      const response = await fetch(form.action || "/api/auth/login.php", {
        method: "POST",
        body: formData,
        credentials: "same-origin",
        headers: {
          "X-Requested-With": "XMLHttpRequest"
        }
      });

      let data = null;
      const ct = response.headers.get("Content-Type") || "";
      if (ct.includes("application/json")) {
        data = await response.json().catch(() => null);
      }

      if (response.ok && data && data.ok) {
        window.location.href = "/acceuil-client";
        return;
      }

      let msg =
        "La connexion n’a pas pu être effectuée. Vérifiez vos identifiants et réessayez.";

      if (data && typeof data === "object" && data.code) {
        if (data.code === "invalid_credentials") {
          msg =
            "Identifiants incorrects. Merci de vérifier votre e-mail / téléphone et votre mot de passe.";
        } else if (data.code === "inactive_account") {
          msg =
            "Votre compte n’a pas encore été vérifié. Vous pouvez recevoir un nouveau code d’activation ou réinitialiser votre mot de passe pour l’activer.";
          if (inactiveCta) {
            inactiveCta.style.display = "block";
          }
        } else if (data.message) {
          msg = data.message;
        }
      } else if (response.status === 401) {
        msg =
          "Identifiants incorrects. Merci de vérifier votre e-mail / téléphone et votre mot de passe.";
      } else if (response.status === 400) {
        msg =
          "Certaines informations sont manquantes ou invalides. Merci de les corriger puis de réessayer.";
      } else if (response.status >= 500) {
        msg = "Erreur serveur. Merci de réessayer dans quelques instants.";
      }

      showGlobalError(msg);
    } catch (err) {
      showGlobalError(
        "Erreur réseau ou serveur. Merci de vérifier votre connexion et de réessayer."
      );
      hideInactiveCta();
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.textContent = "Se connecter";
      }
    }
  }

  form.addEventListener("submit", handleSubmit);
});