<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$isLoggedIn = !empty($_SESSION['user_id']);
$userName   = $_SESSION['user_name'] ?? null;
?>

<header class="bx-header">
  <style>
    /* Uniquement les styles spécifiques au header qui ne sont PAS déjà dans global.css */

    .bx-header-actions {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .bx-theme-toggle {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 34px;
      height: 34px;
      border-radius: 999px;
      border: 1px solid var(--bx-border-subtle);
      background: var(--bx-surface-soft);
      color: var(--bx-text-dim);
      cursor: pointer;
      padding: 0;
      transition:
        background 0.18s ease-out,
        color 0.18s ease-out,
        border-color 0.18s ease-out,
        transform 0.15s ease-out,
        box-shadow 0.18s ease-out;
    }

    .bx-theme-toggle:hover {
      background: var(--bx-glass);
      color: var(--bx-link-hover);
      border-color: var(--bx-border-accent);
      box-shadow: 0 0 0 1px rgba(37, 99, 235, 0.35);
      transform: translateY(-1px);
    }

    .bx-theme-toggle-icon {
      font-size: 16px;
      line-height: 1;
      display: block;
    }

    /* Bouton burger */
    .bx-burger {
      display: none; /* visible uniquement sur mobile */
      flex-direction: column;
      justify-content: center;
      gap: 4px;
      width: 34px;
      height: 34px;
      padding: 0;
      border-radius: 999px;
      border: 1px solid var(--bx-border-subtle);
      background: var(--bx-surface-soft);
      cursor: pointer;
    }

    .bx-burger span {
      display: block;
      width: 16px;
      height: 2px;
      border-radius: 999px;
      background: var(--bx-text);
      margin: 0 auto;
    }

    /* Panel mobile (caché par défaut) */
    .bx-header-mobile-panel {
      display: none;
      background: var(--bx-header-panel-bg);
      border-bottom: 1px solid var(--bx-border-subtle);
    }

    .bx-header-mobile-panel.is-open {
      display: block;
    }

    .bx-header-mobile-inner {
      padding: 10px 16px 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .bx-header-mobile-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }

    .bx-header-mobile-nav {
      display: flex;
      flex-direction: column;
      gap: 4px;
      font-size: 14px;
    }

    .bx-header-mobile-nav a {
      padding: 8px 10px;
      border-radius: 10px;
      color: var(--bx-link);
      text-decoration: none;
      border: 1px solid transparent;
    }

    .bx-header-mobile-nav a:hover {
      background: var(--bx-glass);
      border-color: var(--bx-border-accent);
      color: var(--bx-link-hover);
    }

    @media (max-width: 767px) {
      .bx-header-actions {
        gap: 6px;
      }

      /* on cache la nav horizontale sur mobile */
      .bx-header-nav {
        display: none;
      }

      /* on cache le switch + bouton CTA sur mobile */
      .bx-header-actions .bx-theme-toggle,
      .bx-header-actions .bx-btn-glass {
        display: none;
      }

      .bx-burger {
        display: inline-flex;
      }

      /* on désactive le panneau hover desktop sur mobile */
      .bx-header-panel-wrap {
        display: none;
      }
    }
  </style>

  <div class="bx-header-inner">
    <!-- Barre principale -->
    <div class="bx-header-main">
      <div class="bx-header-main-row">
        <!-- Logo -->
        <a href="/acceuil" class="bx-header-logo">
          <img src="/assets/img/logo-bx-light.png" alt="BillXpert" />
          <div class="bx-header-logo-text">
            <span class="bx-header-logo-title">BillXpert</span>
            <span class="bx-header-logo-sub">Factur-X &amp; facturation BTP</span>
          </div>
        </a>

        <!-- Nav desktop -->
        <nav class="bx-header-nav">
          <a href="/acceuil">Accueil</a>
          <a href="/produit">Produit</a>
        </nav>

        <!-- Switch thème + CTA (desktop) + burger -->
        <div class="bx-header-actions">
          <!-- Switch de thème (desktop) -->
          <button
            type="button"
            class="bx-theme-toggle"
            aria-label="Changer le thème"
            aria-pressed="false"
            data-bx-theme-toggle
          >
            <span class="bx-theme-toggle-icon" data-bx-theme-icon>🌓</span>
          </button>

          <!-- CTA connexion / espace (desktop) -->
          <?php if ($isLoggedIn): ?>
            <a href="/acceuil-client" class="bx-btn-glass">
              <?php if ($userName): ?>
                Mon espace (<?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8'); ?>)
              <?php else: ?>
                Mon espace
              <?php endif; ?>
            </a>
          <?php else: ?>
            <a href="/connexion" class="bx-btn-glass">Se connecter</a>
          <?php endif; ?>

          <!-- Burger (mobile only) -->
          <button
            type="button"
            class="bx-burger"
            aria-label="Ouvrir le menu"
            aria-expanded="false"
            data-bx-nav-toggle
          >
            <span></span>
            <span></span>
            <span></span>
          </button>
        </div>
      </div>
    </div>

    <!-- Panneau déroulant desktop (inchangé) -->
    <div class="bx-header-panel-wrap">
      <div class="bx-header-panel">
        <div class="bx-header-panel-inner">
          <!-- Produit -->
          <div>
            <div class="bx-header-panel-title">Produit</div>
            <a href="/produit" class="bx-menu-link">Détails du logiciel</a>
            <a href="/reforme-2026" class="bx-menu-link">À quoi sert le logiciel ?</a>
            <a href="/tarifs" class="bx-menu-link">Tarifs</a>
          </div>

          <!-- Aide -->
          <div>
            <div class="bx-header-panel-title">Aide</div>
            <a href="/help" class="bx-menu-link">FAQ &amp; contact</a>
          </div>

          <!-- Légal -->
          <div>
            <div class="bx-header-panel-title">Légal</div>
            <a href="/politique-confidentialite" class="bx-menu-link">Politique de confidentialité</a>
            <a href="/conditions-utilisation" class="bx-menu-link">Conditions d’utilisation</a>
            <a href="/mentions-legales" class="bx-menu-link">Mentions légales</a>
            <a href="/gestion-cookies" class="bx-menu-link">Gestion des cookies</a>
          </div>

          <!-- Compte -->
          <div>
            <div class="bx-header-panel-title">Compte</div>

            <?php if ($isLoggedIn): ?>
              <a href="/acceuil-client" class="bx-menu-link">Mon espace</a>
              <a href="/api/auth/logout.php" class="bx-menu-link">Déconnexion</a>
            <?php else: ?>
              <a href="/connexion" class="bx-menu-link">Se connecter</a>
              <a href="/inscription" class="bx-menu-link">Créer un compte</a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- Panneau mobile (burger) -->
    <div class="bx-header-mobile-panel" data-bx-nav-panel>
      <div class="bx-header-mobile-inner">
        <!-- Ligne du haut : switch thème + éventuellement texte -->
        <div class="bx-header-mobile-top">
          <span style="font-size:13px;color:var(--bx-text-dim);">
            Menu BillXpert
          </span>
          <!-- Switch de thème (mobile) -->
          <button
            type="button"
            class="bx-theme-toggle"
            aria-label="Changer le thème"
            aria-pressed="false"
            data-bx-theme-toggle
          >
            <span class="bx-theme-toggle-icon" data-bx-theme-icon>🌓</span>
          </button>
        </div>

        <!-- Liens -->
        <nav class="bx-header-mobile-nav">
          <a href="/acceuil">Accueil</a>
          <a href="/produit">Produit</a>
          <a href="/tarifs">Tarifs</a>
          <a href="/reforme-2026">Réforme 2026</a>
          <a href="/help">FAQ &amp; contact</a>

          <?php if ($isLoggedIn): ?>
            <a href="/acceuil-client">Mon espace</a>
            <a href="/api/auth/logout.php">Déconnexion</a>
          <?php else: ?>
            <a href="/connexion">Se connecter</a>
            <a href="/inscription">Créer un compte</a>
          <?php endif; ?>
        </nav>
      </div>
    </div>
  </div>
</header>