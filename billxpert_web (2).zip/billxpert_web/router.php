<?php
$uri = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
$root = __DIR__;
$rootReal = realpath($root);

function bx_content_type($path)
{
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    $types = array(
        "css" => "text/css; charset=utf-8", "js" => "application/javascript; charset=utf-8",
        "mjs" => "application/javascript; charset=utf-8", "html" => "text/html; charset=utf-8",
        "htm" => "text/html; charset=utf-8", "json" => "application/json; charset=utf-8",
        "png" => "image/png", "jpg" => "image/jpeg", "jpeg" => "image/jpeg", "webp" => "image/webp",
        "gif" => "image/gif", "svg" => "image/svg+xml", "ico" => "image/x-icon",
        "woff" => "font/woff", "woff2" => "font/woff2", "ttf" => "font/ttf", "otf" => "font/otf", "pdf" => "application/pdf"
    );
    return $types[$ext] ?? "application/octet-stream";
}
function bx_is_inside_root($path, $rootReal)
{
    $real = realpath($path);
    if ($real === false || $rootReal === false) return false;
    return strpos($real, $rootReal) === 0;
}
function bx_send_static($path, $rootReal)
{
    if (!is_file($path) || !bx_is_inside_root($path, $rootReal)) { http_response_code(404); echo "Fichier introuvable"; exit; }
    while (ob_get_level() > 0) { ob_end_clean(); }
    header("Content-Type: " . bx_content_type($path));
    header("Content-Length: " . filesize($path));
    readfile($path); exit;
}
if ($uri === "/partials/header.php") { header("Content-Type: text/html; charset=utf-8"); require $root . "/partials/header.php"; exit; }
if ($uri === "/" || $uri === "/index.html" || $uri === "/acceuil" || $uri === "/accueil") { bx_send_static($root . "/pages/acceuil.html", $rootReal); }
$requestedPath = $root . $uri;
if ($uri !== "/" && is_file($requestedPath)) { bx_send_static($requestedPath, $rootReal); }
$slug = trim($uri, "/");
if ($slug !== "" && is_file($root . "/pages/" . $slug . ".html")) { bx_send_static($root . "/pages/" . $slug . ".html", $rootReal); }
if ($slug !== "" && is_file($root . "/pages/session/" . $slug . ".php")) { require $root . "/pages/session/" . $slug . ".php"; exit; }
http_response_code(404);
if (is_file($root . "/pages/404.html")) { bx_send_static($root . "/pages/404.html", $rootReal); }
echo "Page introuvable";
